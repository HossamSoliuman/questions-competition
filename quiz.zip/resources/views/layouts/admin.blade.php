@extends('layouts.app')
@section('sidebar')
    @include('layouts.sidebar')
@endsection